import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Event } from './models';  // Importar el modelo Event

@Injectable({
  providedIn: 'root',
})
export class EventosService {
  private apiUrl = 'http://localhost:3000/events'; // Cambiar a la nueva URL base para eventos

  constructor(private http: HttpClient) {}

  // Obtener los eventos de un anfitrión específico
  getEventosPorAnfitrion(anfitrionId: string): Observable<Event[]> {
    return this.http.get<Event[]>(`${this.apiUrl}?userId=${anfitrionId}`);
  }

  // Crear un nuevo evento
  crearEvento(evento: Event): Observable<Event> {
    return this.http.post<Event>(this.apiUrl, evento);
  }
}
