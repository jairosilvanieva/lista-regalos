import { Component, OnInit } from '@angular/core';
import { RegalosService } from '../regalos.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-lista-regalos',
  templateUrl: './lista-regalos.component.html',
  styleUrls: ['./lista-regalos.component.css'],
})
export class ListaRegalosComponent implements OnInit {
  regalos: any[] = [];
  eventoId: string = '';
  private routeSub: Subscription = new Subscription();

  constructor(
    private regalosService: RegalosService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Obtener el eventoId desde la URL
    this.routeSub = this.route.params.subscribe((params) => {
      this.eventoId = params['eventoId'];
      this.cargarRegalos();
    });
  }

  cargarRegalos(): void {
    if (this.eventoId) {
      this.regalosService.getRegalosPorEvento(this.eventoId).subscribe((data: any[]) => {
        this.regalos = data;  // Cargar solo los regalos del evento correspondiente
      });
    }
  }

  ngOnDestroy(): void {
    // Desuscribirse al finalizar el componente para evitar memory leaks
    if (this.routeSub) {
      this.routeSub.unsubscribe();
    }
  }
}
