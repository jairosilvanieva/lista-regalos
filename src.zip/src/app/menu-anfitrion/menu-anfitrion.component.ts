import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventosService } from '../eventos.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-menu-anfitrion',
  templateUrl: './menu-anfitrion.component.html',
  styleUrls: ['./menu-anfitrion.component.css']
})
export class MenuAnfitrionComponent implements OnInit {
  tipoEvento: string = '';
  lugar: string = '';
  fecha: string = '';
  hora: string = '';
  descripcion: string = '';
  eventos: any[] = [];  // Lista de eventos creados por el anfitrión

  constructor(
    private router: Router,
    private eventosService: EventosService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.cargarEventos();
  }

  // Cargar eventos existentes
  cargarEventos() {
    const anfitrionId = this.authService.obtenerAnfitrionId();  // Obtener el ID del anfitrión desde el servicio de autenticación
    if (anfitrionId) {
      this.eventosService.getEventosPorAnfitrion(anfitrionId).subscribe((data) => {
        this.eventos = data;  // Cargar solo los eventos del anfitrión logueado
      }, (error) => {
        console.error('Error al cargar eventos:', error);
      });
    }
  }

  // Crear un nuevo evento
  crearEvento() {
    const anfitrionId = this.authService.obtenerAnfitrionId();  // Obtener el ID del anfitrión desde el servicio de autenticación
    if (anfitrionId) {
      const nuevoEvento = {
        tipoEvento: this.tipoEvento,
        lugar: this.lugar,
        fecha: this.fecha,
        hora: this.hora,
        descripcion: this.descripcion,
        codigo: this.generarCodigoUnico(),  // Generar un código único
        anfitrionId: anfitrionId  // Asociar el evento al anfitrión logueado
      };

      this.eventosService.crearEvento(nuevoEvento).subscribe(() => {
        console.log('Evento creado con éxito');
        alert('Evento creado con éxito');
        this.cargarEventos();  // Recargar la lista de eventos
      }, (error) => {
        console.error('Error al crear el evento:', error);
        alert('Error al crear el evento');
      });
    }
  }

  // Generar un código único para el evento
  generarCodigoUnico(): string {
    let codigoUnico = '';
    let existeCodigo = true;

    // Generar un nuevo código hasta que sea único
    while (existeCodigo) {
      codigoUnico = Math.random().toString(36).substr(2, 8).toUpperCase();
      existeCodigo = this.eventos.some(evento => evento.codigo === codigoUnico);
    }

    return codigoUnico;
  }

  // Redirigir a la página para elegir regalos
  elegirRegalos(eventoId: string) {
    this.router.navigate(['/eventos', eventoId, 'regalos']);  // Pasar el ID del evento para gestionar sus regalos
  }

  // Cerrar sesión
  cerrarSesion() {
    this.authService.cerrarSesion();
  }
}
