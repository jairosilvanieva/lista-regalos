import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventosService } from '../eventos.service';
import { AuthService } from '../auth.service';
import { Event } from '../models';  // Importar el modelo Event

@Component({
  selector: 'app-menu-anfitrion',
  templateUrl: './menu-anfitrion.component.html',
  styleUrls: ['./menu-anfitrion.component.css']
})
export class MenuAnfitrionComponent implements OnInit {
  eventos: Event[] = [];  // Lista de eventos creados por el anfitrión

  constructor(
    private router: Router,
    private eventosService: EventosService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.cargarEventos();
  }

  // Cargar eventos existentes
  cargarEventos() {
    const anfitrionId = this.authService.obtenerAnfitrionId();  // Obtener el ID del anfitrión desde el servicio de autenticación
    if (anfitrionId) {
      this.eventosService.getEventosPorAnfitrion(anfitrionId).subscribe({
        next: (eventos: Event[]) => {
          this.eventos = eventos;
        },
        error: (error: any) => {
          console.error('Error al cargar eventos:', error);
        }
      });
    }
  }
}
