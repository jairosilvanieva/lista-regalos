import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gift } from './models';  // Importar el modelo Gift

@Injectable({
  providedIn: 'root'
})
export class RegalosService {
  private apiUrl = 'http://localhost:3000/gifts';  // Cambiar a la nueva URL base para regalos

  constructor(private http: HttpClient) {}

  // Obtener los regalos filtrados por eventoId
  getRegalosPorEvento(eventoId: string): Observable<Gift[]> {
    return this.http.get<Gift[]>(`${this.apiUrl}?eventId=${eventoId}`);
  }

  // Agregar un regalo
  addRegalo(regalo: Gift): Observable<Gift> {
    return this.http.post<Gift>(this.apiUrl, regalo);
  }

  // Actualizar un regalo
  actualizarRegalo(regalo: Gift): Observable<Gift> {
    return this.http.put<Gift>(`${this.apiUrl}/${regalo.id}`, regalo);
  }
}
