import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
  nombre: string = '';
  email: string = '';
  password: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  registrar() {
    const nuevoAnfitrion = {
      nombre: this.nombre,
      email: this.email,
      password: this.password
    };

    this.authService.registrarAnfitrion(nuevoAnfitrion).subscribe(() => {
      alert('Registro exitoso');
      this.router.navigate(['/login']);  // Redirige al login tras el registro exitoso
    });
  }
}
