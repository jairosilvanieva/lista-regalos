import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { User } from '../models';  // Importar el modelo User

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css'],
})
export class RegistroComponent {
  nombre: string = '';
  email: string = '';
  password: string = '';

  constructor(private authService: AuthService) {}

  registrar(): void {
    const nuevoAnfitrion: User = {
      id: '',  // El ID será generado automáticamente por el servidor
      name: this.nombre,
      email: this.email,
      password: this.password,
      events: []
    };

    this.authService.registrarAnfitrion(nuevoAnfitrion).subscribe({
      next: () => {
        alert('Registro exitoso');
      },
      error: (error) => {
        console.error('Error al registrar el anfitrión:', error);
      },
    });
  }
}
